BLOCKCHAIN BASED BLUE CARBON REGISTRY AND MRV SYSYTEM BY TEAM KALKI.

[![Watch the video](https://img.youtube.com/vi/aKaD_g4Ogv8/0.jpg)](https://youtu.be/aKaD_g4Ogv8)

<sub>Click the image above to watch the video on YouTube.</sub>
